/* Programming Fundamentals Final Project Fall 2024
Name: Hammad Mustafa
ID: 24i-0519
Objective: To Replicate Buzz bombers using c++ and SFML
*/

#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <fstream> // I have added this library to perform file handling operations related to scores...

using namespace std;
using namespace sf;

//======================================================= Initializing Dimensions ============================================.
//=== resolutionX and resolutionY determine the rendering resolution.

const int resolutionX = 960;
const int resolutionY = 640;
const int boxPixelsX = 32;
const int boxPixelsY = 32;
const int gameColumns = resolutionX / boxPixelsX; // Total rows on grid
const int gameRows = resolutionY / boxPixelsY; // Total columns on grid

//========== Initializing GameGrid.
int gameGrid[gameRows][gameColumns] = {};
//===================================================== Functions Declerations =========================================================


void drawPlayer(RenderWindow& window, float [], float [], Sprite& playerSprite); // To draw the player

void movePlayer_right (float [],float [], float&, double&,float&, int&,bool&,bool&); // To move the player right

void movePlayer_left (float [],float [], float&, double&,float&, int&,bool&,bool&); // To move the player left

void moveBullet(float& bullet_y, bool& bullet_exists, bool& , Clock& bulletClock); // To move the bullet upwards

void drawBullet(RenderWindow& window, float& bullet_x, float& bullet_y, Sprite& bulletSprite); // to draw the bullet

// Arrays are by default passed by reference so there is no need to explicitly mention about it using &

void drawBee(RenderWindow& window, float bee_x[], float bee_y[], int& ,Sprite& bee_sprite); // to draw the bees

void moveBee(float [], float [], bool [], bool [],int&,bool&,int&,bool& ,int& , float&,int&, Texture& ); // to move the bees

void bee_spawn(float [], float [], int& ,const int& ,Clock&); // to spawn bees on the screen after regular intervals

void bullet_bee_collision ( float& , float& , float [], float [],int [], int [], int&,int&, bool&,bool& ,int&,int&,int&, Music& ) ; // To detect bullet and bee collisiom

void drawHoneycomb (RenderWindow& window, int[], int[],int&,int&, int&,bool& , int& ,Sprite& hive_sprite); //to draw the honeycombs

void drawflower(RenderWindow& window, float [] , float& , int& ,bool& ,bool&,bool& ,int& , Sprite&); // to draw the flowers

void bullet_comb_collision ( float& ,float& , int [], int [] , int&,bool&,int&,Music&); // to detect bullet and comb collision

void bee_comb_collision ( float [] , float [] , int [], int [],float [] , float[] ,int&,int&,int&,float& ); // to detetct bee and comb collison

void player_fl ( float [] , float [] , float& , int&, double& , float&, bool& , bool& ); // to check collision between the player and the flowers

void humming_bird (RenderWindow& window , float& , float& ,float& ,bool& alt,int& , int&,  Sprite&, Clock& ); // To draw the humming bird

void drawHives ( RenderWindow& window , float [] , float [] ,int& , int&, Sprite& ); // To draw the hives

void bullet_hive_collision ( float [] , float [] , float& , float& , int&,bool&); // to detect bullet and hive collision

void draw_fast_bees ( RenderWindow& window, float [] , float [] ,int& , int&,Sprite& ); // to draw the fast bees

void move_fast_bees ( float [] , float [] , int& , int&, bool [] , bool [],int&, float& ); // to move the fast bees

void spawn_fast_bees ( float [] , float [] , int& , int& ,Clock&); // to spawn the fast bees after regular intervals

void bullet_fast_bee_collision ( float& , float& ,float [] , float [] , float [] , float [] , int& ,int&, bool& ,int& ,int&, Music& ); // to detect bullet and fast bee collision

void draw_red_comb (RenderWindow& window, float [], float [], int& , Sprite&); // to draw the red combs created by fast bee

void reg_bee_red_comb ( float [] ,float [], float [] , float [] , int& , int&, float&,int&, float [] , float []); // to detect collision between regular bee and red comb 

void bullet_red_comb ( float [] , float [] , float& , float& , int& ); // to detect bullet and red comb detection

void levels ( int& , int& , int& ,int& , int& , int& ,int&); // to check level status and update accordingly ( not used )

void h_bird_comb_collision (float& ,float&, int [], int [] , float [] , float [] , int&, int&, int& ); // to detect humming bird and its collision with combs for score

void bullet_h_bird_collision ( float& , float&, float&, float& ,int&,float&,bool&, Clock& ); // to detect collision between bullet and humming bird for sickness


//void bee_stop ( float [] , float [], bool [] , bool [], int&, float& );

//================================================================================================================================================
//================================================================== Main Function ===============================================================
//================================================================================================================================================

int main()
{
	srand(time(0));

	// Declaring RenderWindow.
	RenderWindow window(VideoMode(resolutionX, resolutionY), "Buzz Bombers", Style::Close | Style::Titlebar);

	// Used to position your window on every launch. Use according to your needs.
	window.setPosition(Vector2i(500, 200));
	
//=================================================================== Music Inventory ===================================================================
	//=============== Background Music.
	Music bgMusic;
	if (!bgMusic.openFromFile("Music/Music3.ogg")) {
    cout << "Error: Could not load music file!" << endl;
	}
	bgMusic.setVolume(50);
	bgMusic.setLoop(true);
	//bgMusic.play();
	//Collision Music
	Music collision;
	collision.openFromFile("Sound/collision.wav");
	collision.setVolume(50);
	
	Music mainmenu;
	mainmenu.openFromFile("Music/menu.ogg");
	mainmenu.setVolume(50);
	

//==================================================================== Text/Output Inventory ====================================================================
  // ======Score Updates 
	int Score=0;
	
	Font font;
	font.loadFromFile("Textures/Sans.ttf");
	
	Text score;
	score.setFont(font);
	score.setFillColor(sf::Color::White);
	score.setString("Score: " + std::to_string(Score));
	score.setCharacterSize(30);
	score.setPosition(resolutionX-200,resolutionY-boxPixelsY-40);
	
  //==== Spray Can 
   unsigned int Sprays=56;
  
  Text sprays;
  sprays.setFont(font);
  sprays.setFillColor(sf::Color::Blue);
  sprays.setString("Sprays left " + std::to_string(Sprays));
  sprays.setCharacterSize(30);
  sprays.setPosition((gameColumns / 2) * boxPixelsX-34,resolutionY-boxPixelsY-40);
  
  //=========Main Menu
  Font menuFont;
  menuFont.loadFromFile ("Textures/poppin.ttf");
  
  Text title;
  title.setFont(menuFont);
  title.setFillColor(sf::Color::Yellow);
  title.setString("BUZZ BOMBERS");
  title.setCharacterSize(60);
  title.setPosition (resolutionX/2-200,(resolutionY-100)/2-100);
  
  
  int choice=0;
  const int size=4;
  Text main_menu[size];
  string choices[size]={"Start Game" ,"BOSS LEVEL", "Score" , "Exit"};
  
  for (int i=0; i<size; i++) 
  {
   main_menu[i].setFont(menuFont);
        {
        main_menu[i].setString(choices[i]);
        main_menu[i].setCharacterSize(40);
        main_menu[i].setPosition(resolutionX/2-100,(resolutionY-100)/2+50*i);
        main_menu[i].setFillColor(i==choice ? Color::Blue : Color::White); 
        }
  
  }
  Text gameover;
  gameover.setFont(menuFont);
  gameover.setFillColor(sf::Color::Red);
  gameover.setString("GAME OVER");
  gameover.setCharacterSize(60);
  gameover.setPosition (resolutionX/4,boxPixelsY);
  
  Text nameprompt;
  nameprompt.setFont(menuFont);
  nameprompt.setFillColor(sf::Color::Red);
  nameprompt.setString("Enter Your Name");
  nameprompt.setCharacterSize(60);
  nameprompt.setPosition (resolutionX/2-200,(resolutionY-100)/2-100);
  
  Text highscore_display;
  highscore_display.setFont(font);
  highscore_display.setFillColor(sf::Color::Red);
  highscore_display.setString("HIGH SCORES");
  highscore_display.setCharacterSize(80);
  highscore_display.setPosition((resolutionX-boxPixelsX)/4,32);
  
//================================================================================ Levels logic ==============================================================
int max_levels=3;
int curr_level=1;
bool boss_level=false;
int Spray_cans=3;

//==============================================================================================================================================================================
//================================================================================= MAIN MENU =================================================================================	
//============================================================================================================================================================================
 bool game_open=false;
 bool name_entered=false;
 bool score_display=false;
 
 while (!game_open)
 {
 
   Event menu;
   while (window.pollEvent(menu))
   {
    if (menu.type==Event::Closed)
    {
    window.close();
    }
     
     
    if (menu.type==Event::KeyReleased)
    {
     if (menu.key.code==Keyboard::Up)
     {
      choice=(choice-1)%4; // Mod 4 to ensure that the choice remains between the options stored in the array
     } 
     else if (menu.key.code==Keyboard::Down) 
     {
       choice=(choice+1)%4;
     }  
     else if (menu.key.code==Keyboard::Enter) 
     {
          if (choice==0) 
          {
          name_entered=true; // to display the name prompt screen
          game_open=!game_open;
          }
           else if (choice==1) 
           {
            boss_level=true; // to make adjustments for boss level later on
            name_entered=true;
           game_open=!game_open;
           } 
           else if (choice==2) 
           {
           score_display=true; // to trigger event to display scores
            game_open=!game_open;
                      
        }
         else if (choice==3)
         {
            window.close();  // If exit then close the window
         }
     }
     // to set colors of the options selected and not selected
      for (int i=0; i<size; i++) 
      {
      main_menu[i].setFillColor(i==choice ? Color::Red:Color::White);
      }
      }
      }
       
        window.clear(Color::Black);
        
       
        window.draw(title); // To display Game title
        
        // To display the elements of the menu for naviagtion
        for (int i=0; i<size; i++) {
            window.draw(main_menu[i]);
        }
         window.display();
        
 }
 
 
//===============================================================================================================================================================    
//================================================================== Game Objects Data ==========================================================================
//===============================================================================================================================================================     
	// Initializing Player and Player Sprites.
	 float player_x[3],player_y[3];
	 
	 player_x[0]=(gameColumns / 2) * boxPixelsX;
	 player_y[0]=(gameRows - 4) * boxPixelsY;
	 
	 player_x[1]=0;
   	 player_y[1]=(gameRows - 2) * boxPixelsY;
	 
	 player_x[2]=48;
	 player_y[2]=(gameRows - 2) * boxPixelsY;
	
	bool left=false , right=false;
	
    Clock playerclock;
	Texture playerTexture;
	Sprite playerSprite;
	playerTexture.loadFromFile("Textures/spray.png");
	playerSprite.setTexture(playerTexture);
	double player_speed=100;
	
	
	
	// Initialiting bee and bee sprites
	const int max_bees=20;
	int present_bees=0;
	float bee_x[max_bees]={0};
	float bee_y[max_bees]= {0};
	bool moveRight[max_bees]={true},moveLeft[max_bees]={false};
	
	
	Clock beespawn,beeclock;
	Texture bee_texture;
	Sprite bee_sprite;
	bee_texture.loadFromFile("Textures/Regular_bee_right.png");
	bee_sprite.setTexture(bee_texture);
	bee_sprite.setScale(1 , 1);
	int tempX,tempY;
	//	playerSprite.setTextureRect(IntRect(0, 0, boxPixelsX, boxPixelsY));

	
       // Initializing Bullet and Bullet Sprites
      // Data for bullet / Spray pellet

	float bullet_x = player_x[0];
	float bullet_y = player_y[0];
	bool bullet_exists = true;
	
	
	Clock bulletClock;
	Texture bulletTexture;
	Sprite bulletSprite;
	bulletTexture.loadFromFile("Textures/bullet.png");
	bulletSprite.setTexture(bulletTexture);
	bulletSprite.setScale(1, 1);
	bulletSprite.setTextureRect(sf::IntRect(0, 0, boxPixelsX, boxPixelsY));
	bool bullet_fired=false;
	
	int max_honeycomb=0 , honeycomb=0;
	// and honeycombs
	
	if (boss_level==false)
	{
     max_honeycomb=55;
     honeycomb=3;
	}
	else
	{
	 max_honeycomb=35;
     honeycomb=15;
	}
	
	int honeycomb_x[max_honeycomb], honeycomb_y[max_honeycomb];
	for (int i=0; i<honeycomb ; i++) 
    {
      honeycomb_x[i]= rand()%(resolutionX-boxPixelsX);
      honeycomb_y[i]=rand()%((gameRows - 4) * boxPixelsY);
    }
	
	Texture comb_texture;
	Sprite comb_sprite;
	comb_texture.loadFromFile("Textures/honeycomb.png");
	comb_sprite.setTexture(comb_texture);
	comb_sprite.setScale( 1 , 1);
	comb_sprite.setTextureRect(sf::IntRect(0, 0, boxPixelsX*2, boxPixelsY*2));
   
   // Initializing the Flowers
   const int max_fl=gameColumns;
   bool flower_time=false;
   
   Texture flower_texture;
   Sprite flower_sprite;
   flower_texture.loadFromFile("Textures/flower.png");
   flower_sprite.setTexture(flower_texture);
   flower_sprite.setScale(1,1);
   flower_sprite.setTextureRect(sf:: IntRect(0,0,boxPixelsX , boxPixelsY));
   int present_fl=0;
   float fl_x[gameColumns]={}, fl_y=(gameRows - 3) * boxPixelsY;
   bool alt=false;

	// The ground on which player moves

	RectangleShape groundRectangle(Vector2f(960, 64));
	groundRectangle.setPosition(0, (gameRows - 2) * boxPixelsY);
	groundRectangle.setFillColor(Color::Green);
	
	//======Humming bird
	Clock h_bird;
	float h_bird_x=0, h_bird_y=0;
	Texture humming_texture;
	Sprite humming_sprite;
	humming_texture.loadFromFile("Textures/bird.png");
	humming_sprite.setTexture(humming_texture);
	humming_sprite.setScale(2 , 2);
	humming_sprite.setTextureRect(sf::IntRect(0,0,boxPixelsX,boxPixelsY));
	int destination_x=rand()%(resolutionX-boxPixelsX)+1;
	int destination_y=rand()%(gameRows - 4) * boxPixelsY;
	
	//====== Hives 
	int max_fast=0;
	int hives=0;
	int max_hives=0;
	int present_fast=0;
	
	if (boss_level==false)
	{
	
	 hives=0;
	 max_hives=20;
	
	//=========== Fast Bees
	 max_fast=10;
	 present_fast=0;
	
	}
	
	else
	{
	
	 hives=5;
	 max_hives=25;
	
	
	//=========== Fast Bees
	 max_fast=15;
	 present_fast=0;
	
	
	}
	
	
	float hives_x[max_bees]={-1} , hives_y[max_bees]={-1};
	float fast_bee_x[max_fast] , fast_bee_y[max_fast];
	
	for (int i=0; i<hives ; i++) 
    {
      hives_x[i]= rand()%(resolutionX-boxPixelsX);
      hives_y[i]=rand()%((gameRows - 4) * boxPixelsY);
    }
	
	Texture hive_texture;
	Sprite hive_sprite;
	hive_texture.loadFromFile ("Textures/hive.png");
	hive_sprite.setTexture(hive_texture);
	hive_sprite.setScale(1 , 1);
	hive_sprite.setTextureRect(sf::IntRect(0,0,boxPixelsX*2,boxPixelsY*2));
	
	
	
	
	Clock fast_bee_clock;
	Texture fast_texture;
	Sprite fast_sprite;
	fast_texture.loadFromFile("Textures/Fast_bee.png");
	fast_sprite.setTexture(fast_texture);
	fast_sprite.setScale(1 , 1);
	fast_sprite.setTextureRect(sf::IntRect(0,0,boxPixelsX,boxPixelsY));
	bool right_fast[max_fast]={true} , left_fast[max_fast]={false};
	
//===========Red honeycomb	
    
    
	int present_red_comb=0;
	float red_x[max_fast] , red_y[max_fast];
	
	Texture red_texture;
	Sprite red_sprite;
	red_texture.loadFromFile ("Textures/honeycomb_red.png");
	red_sprite.setTexture ( red_texture );
	red_sprite.setScale( 1 , 1);
	red_sprite.setTextureRect(sf::IntRect(0, 0, boxPixelsX*2, boxPixelsY*2));
	
	

////////////////////////////====================================================== Some Variables for Game Logic =========================================////////////////////
bool center=false;	
int fl;
int reg_bee_killed=0;
int bee_escape=0;
int fast_bee_killed=0;
bool lvl_2=false;
int h_bird_hit=0;


/////============================================================================ FILE HANDLING OPERATIONS ==================================================================

  const int file_data_size=10;
  
  Text name, highscore ;
  String data_assign='\0';
  
  name.setFont(menuFont);
  name.setFillColor(sf::Color::Yellow);
  name.setCharacterSize(45);
  name.setPosition (resolutionX/2-200,(resolutionY-100)/2-100);
  
  highscore.setFont(menuFont);
  highscore.setFillColor(sf::Color::Yellow);
  highscore.setCharacterSize(45);
  highscore.setPosition (resolutionX/2,(resolutionY-100)/2-100);
  
  
  int scores[file_data_size]; 
  string player_name[file_data_size];
   
  // Reading Data from the file and storing them in relevent arrays
  
  ifstream input_file;
  input_file.open("data.txt");
  
  for (int i=0;i<file_data_size ;i++)
   {
		input_file >> player_name[i];
		input_file >> scores[i];
   }
  input_file.close();
 // cout<<player_name[3];
  
  // Sorting the array by selection sort algo
  
   for (int i=0; i<file_data_size;i++)
    {
     for (int j=i+1; j<file_data_size; j++)
     {
      if ( scores[i] < scores[j] )
       {
         int temp_s = scores[i];
         string temp_n=player_name[i];
         
         scores[i]=scores[j];
         player_name[i]=player_name[j];
         
         scores[j]=temp_s;
         player_name[j]=temp_n;
       }
     
     } 
    
    }
   
  // To store data in the form of string extracted from the array to be displayed on the menu
   	for (int i=0;i<file_data_size;i++)
   	{
	data_assign+= player_name[i];
    data_assign+='\n';
	}
	name.setString(data_assign);  
	
	data_assign='\0';
	
	for (int i=0;i<file_data_size;i++)
   	{
	data_assign+= to_string(scores[i]);
    data_assign+='\n';
	}
	highscore.setString(data_assign);  
	
	
	Text text_enter;
	text_enter.setFont(menuFont);
	text_enter.setFillColor(sf::Color::White);
    text_enter.setCharacterSize(45);
    text_enter.setPosition (resolutionX/2-100,(resolutionY-100)/2);
	

 //============================================================== Asking for the name from the user ========================================================================
 char user_name[20]={'\0'};
 int index=0;
 char alpha; // to store and assign the character pressed by the user into the naming array
 
 while (name_entered)
 {
 
 Event n;
 while (window.pollEvent(n))
 {  
    if (n.type==Event::Closed)
    {
    window.close();
    }
  
   if (n.type==Event::TextEntered)
   {
     alpha=n.text.unicode;
     
    if (alpha==8) // Detection of Backspace key
    {
       if (index>0)
        {
      index--;
      user_name[index]='\0';    
        }
    }
    
    else if ( alpha==32) //Detetction of Space
    {
     user_name[index]=' ';
     index++;
    }
    else if ( alpha>= 65 && alpha <= 122) 
    {
    user_name[index]=alpha;
    index++;
    }
    text_enter.setString(user_name);
 }

   if (n.type==Event::KeyReleased)
   
   {
    if (n.key.code==Keyboard::Right) // If user presses right button then continue to the game
    {
      name_entered=false;
      
    }
   
   
   }
   window.clear(sf::Color::Black);
   window.draw(text_enter);
   window.draw(nameprompt);
   //window.draw(name);
   window.display();
 
 }
}
//================================================================== Score Sheet ============================================================================================

while (score_display)
{
Event s;

while (window.pollEvent(s))
{
  if (s.type==Event::Closed)
    {
    window.close();
    }
  if (s.type==Event::KeyReleased)
   
   {
    if (s.key.code==Keyboard::Right)
    {
      score_display=false;
    }
   
   
   }
    
}

   window.clear (sf::Color::Black);
   window.draw(highscore_display);
   window.draw(name);
   window.draw(highscore);
   window.display();
   


}


//============================================================================================================================================================================	
//============================================================================================================================================================================
//-------------------------------------------------------------------------- Main Game Loop -----------------------------------------------------------------------------------
//============================================================================================================================================================================
//============================================================================================================================================================================
	int lives=0;
	bool game_run=false;
	bgMusic.play();
	while (window.isOpen()) {
   
   
		Event e;
		while (window.pollEvent(e)) {
			if (e.type == Event::Closed) {
				window.close();
			} // I have created another command here becuase when i did the same below, the sprays instantly decremented to zero
			if (e.type == sf::Event::KeyPressed && e.key.code == sf::Keyboard::Space) {
			    if (bullet_exists)
			    {
                if (Sprays>0) 
                 {
                 Sprays--;
                 lives++;
                 }
                 else
                 {
                 // To replace the spray cans
                 
                 if (lives==56) 
                 {
                 player_x[1]=-10000;
                 player_y[1]=-100000;
                 Sprays=56;
                 }
                 else if (lives==112)
                 {
                   player_x[2]=-10000;
                   player_y[2]=-10000;
                   Sprays=56;
                 }
                 
                 
                 }  
		        }
		
		}
		
		}
                 
		
		//======================================================================== 
		// float timetrack = playerclock.restart().asSeconds();
        
        //bool space_press=false;
        
              //==================================================Bullet Movement Control===============================================================
        if (Sprays>0) // To make sure bullet only comes out if there is spray left else no
        {
		if (bullet_exists == true && lives<168)
		{
		      
		 if (sf::Keyboard::isKeyPressed (sf::Keyboard::Space))
		        {
		          bullet_fired=true;
		  //        space_press=true;
		      
		        }
		        
		        
		   if (bullet_fired==true)
		  {   
			moveBullet(bullet_y, bullet_exists,bullet_fired, bulletClock);
		
		  }   
				drawBullet(window, bullet_x, bullet_y, bulletSprite);
			
		}
		else
		{   bullet_exists=true;
		    bullet_fired=false;
			bullet_x = player_x[0];
			bullet_y = player_y[0];
		}
		}
		
		
		
	//======================================================= Player Movement Control===========================================================	
	    float timetrack = playerclock.restart().asSeconds(); // To measure the time between each frame for smooth running of the game
	    
		if ( sf::Keyboard::isKeyPressed (sf::Keyboard::Key::Right))
		{
                movePlayer_right (player_x,fl_x, timetrack, player_speed,bullet_x, present_fl, right , left);
                }
                else if ( sf::Keyboard::isKeyPressed (sf::Keyboard::Key::Left))
                {
                movePlayer_left (player_x,fl_x, timetrack, player_speed,bullet_x, present_fl, left , right);
                }
             //========================================Bee Movement Control=============================================  
           float bee_timetrack=beeclock.restart().asSeconds(); 
                if (present_bees <= max_bees)
                {
                bee_spawn (bee_x , bee_y ,present_bees,max_bees,beespawn);
                drawBee(window, bee_x, bee_y, present_bees, bee_sprite);
                moveBee(bee_x , bee_y,moveLeft,moveRight, present_bees ,flower_time, present_fl,center,fl, bee_timetrack,bee_escape,  bee_texture);
              //  bee_stop ( bee_x , bee_y , moveRight , moveLeft , present_bees , timetrack);
               	
                }	
                bool collision_status=false;
    //================================================================ Other Functions Calling ===================================================
    
    
	 
        drawflower(window, fl_x, fl_y, present_fl, flower_time, alt,center, fl , flower_sprite);
         
        player_fl ( player_x , fl_x ,bullet_x , present_fl, player_speed , timetrack, left , right  );
        
        bullet_comb_collision ( bullet_x ,  bullet_y ,  honeycomb_x,  honeycomb_y ,honeycomb,bullet_exists,max_honeycomb,collision); 	
         	
		bullet_bee_collision( bullet_x , bullet_y, bee_x , bee_y ,honeycomb_x,honeycomb_y,present_bees,honeycomb, collision_status ,bullet_exists,Score,reg_bee_killed,max_honeycomb, collision);
		
		drawHoneycomb(window , honeycomb_x , honeycomb_y, tempX, tempY, honeycomb,collision_status,max_honeycomb, comb_sprite);
		
		
	    bee_comb_collision ( bee_x ,  bee_y , honeycomb_x, honeycomb_y,  hives_x ,  hives_y ,  present_bees,honeycomb, hives ,  timetrack );
	    	     
		humming_bird (window , h_bird_x , h_bird_y ,timetrack , alt,destination_x, destination_y,humming_sprite, h_bird );
		
		bullet_h_bird_collision (  bullet_x ,  bullet_y, h_bird_x, h_bird_y , h_bird_hit, timetrack, bullet_exists, h_bird );

        //	void h_bird_comb_collision (float& ,float&, int [], int [] , float [] , float [] , int&, int&, int& );

        h_bird_comb_collision ( h_bird_x , h_bird_y ,  honeycomb_x, honeycomb_y , red_x , red_y , present_red_comb , honeycomb,  Score );

		drawHives (window , hives_x , hives_y, hives, max_hives, hive_sprite);
		
		bullet_hive_collision ( hives_x , hives_y , bullet_x, bullet_y, hives,bullet_exists);
		
		
		
		if (curr_level<=max_levels)
		{
		 if (reg_bee_killed+bee_escape+hives >=20 )
	      curr_level++;
		}
//============================================================================ LEVEL SPECIFICATION ===========================================================================		
		if (curr_level>=2 && boss_level==false)
		{
		  
		  
		  if (!lvl_2)
		  {
		  // Drawing the initial pre generated honeycombs for level 2
		  honeycomb=9;
		  for (int i=0; i<honeycomb ; i++) 
        {
      honeycomb_x[i]= rand()%(resolutionX-boxPixelsX);
      honeycomb_y[i]=rand()%((gameRows - 4) * boxPixelsY);
      
        }
                 
		  present_bees=0;
		  present_fast=0;
		  lvl_2=!lvl_2;
		  }
	//	  drawHoneycomb(window , honeycomb_x , honeycomb_y, tempX, tempY, honeycomb,collision_status,max_honeycomb, comb_sprite);
		  
		  spawn_fast_bees ( fast_bee_x ,  fast_bee_y , present_fast,   max_fast , fast_bee_clock);
		  
		  draw_fast_bees ( window,  fast_bee_x , fast_bee_y , present_fast ,  max_fast, fast_sprite );
		  
		  move_fast_bees ( fast_bee_x ,  fast_bee_y ,  present_fast ,  max_fast ,  left_fast ,  right_fast,present_fl, timetrack );
		  
		  bullet_red_comb (  red_x ,  red_y  ,  bullet_x , bullet_y ,  present_red_comb );
		  
		  bullet_fast_bee_collision ( bullet_x , bullet_y ,fast_bee_x , fast_bee_y , red_x  , red_y , present_fast , present_red_comb, bullet_exists ,Score,fast_bee_killed,      collision );
		  
		  drawflower(window, fl_x, fl_y, present_fl, flower_time, alt,center, fl , flower_sprite);
		  
		  reg_bee_red_comb (  bee_x  , bee_y ,  red_x  ,  red_y  ,  present_bees ,  present_red_comb, timetrack, hives , hives_x,  hives_y);
		  
		  
		  draw_red_comb ( window, red_x , red_y, present_red_comb , red_sprite);
		  
		  drawHives (window , hives_x , hives_y, hives, max_hives, hive_sprite);
		  
		  //reg_bee_killed=0 , bee_escape=0;
		 // honeycomb=3 , present_bees=0;
		}

// Boss level Implementation

		 if (boss_level==true)
		 {
		 
		 spawn_fast_bees ( fast_bee_x ,  fast_bee_y , present_fast,   max_fast , fast_bee_clock);
		  
		  draw_fast_bees ( window,  fast_bee_x , fast_bee_y , present_fast ,  max_fast, fast_sprite );
		  
		  move_fast_bees ( fast_bee_x ,  fast_bee_y ,  present_fast ,  max_fast ,  left_fast ,  right_fast,present_fl, timetrack );
		  
		  bullet_red_comb (  red_x ,  red_y  ,  bullet_x , bullet_y ,  present_red_comb );
		  
		  bullet_fast_bee_collision ( bullet_x , bullet_y ,fast_bee_x , fast_bee_y , red_x  , red_y , present_fast , present_red_comb, bullet_exists ,Score,fast_bee_killed,      collision );
		  
		  drawflower(window, fl_x, fl_y, present_fl, flower_time, alt,center, fl , flower_sprite);
		  
		  reg_bee_red_comb (  bee_x  , bee_y ,  red_x  ,  red_y  ,  present_bees ,  present_red_comb, timetrack, hives , hives_x,  hives_y);
		  
		  
		  draw_red_comb ( window, red_x , red_y, present_red_comb , red_sprite);
		  
		  drawHives (window , hives_x , hives_y, hives, max_hives, hive_sprite);
		 
		 
		
		 }
		 
// If the flowers take over the player ground and no movement is possible then make the socre 0 and remove all the flowers		 
        if (present_fl == max_fl/2)
        {
         lives+=56;
         present_fl=0;
         Score=0;
        }
         
// To check if the all the spray cans are used then exit the game
/*
        if ( lives==168)
         {
           window.clear(sf::Color::Black);
           break;
         }
*/	    
		sprays.setString("Sprays left " + std::to_string(Sprays)); // To display the Sprays left on the screen
		score.setString("Score: " + std::to_string(Score)); // To display the user Score
		
		window.draw(groundRectangle); // To draw the ground
		drawPlayer(window, player_x, player_y, playerSprite);
		window.draw(score);
		window.draw(sprays);
		window.display();
		window.clear();
		
		
	
	
	// To display the highscores after the game is over
	/*
	        window.draw(gameover);
            window.draw(name);
            window.draw(highscore);
            window.display();
		*/ 
	}
//================================================================= Game Loop Ends here ==================================================================================	

//================================================================= Updation of File =====================================================================================	
  // Replacing the score if it falls in the list of high score category and changing the rank of the other accordingly. 
  
  for  (int i=0; i<file_data_size; i++)
  {
   if (Score > scores[i] )
   {
     for (int j=file_data_size-1 ; j>i ; j--)
     {
        scores [j]=scores [j-1];  
        player_name[j]=player_name[j-1];
     }
   }
   scores[i]=Score;
   player_name[i]=user_name;
   break;
  
  }

// Writing Data Back into the file
 string data_write;
 
 ofstream output_file;
 output_file.open ("data.txt");
 
 // Storing all the data into a single string in a formatted form which is then directly written into the file
 
 for (int i=0 ; i<file_data_size; i++)
 {
    data_write+=player_name[i];
    data_write+=' ';
    data_write+= to_string(scores[i]);
    data_write+='\n';
 }
 
 output_file << data_write;
 output_file.close();

}

//===========================================================================================================================================================================
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                                                           //
//                                                              FUNCTIONS DEFINATIONS BELOW THIS DIVIDER                                                     //
//                                                                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//===========================================================================================================================================================================
// To draw Player
void drawPlayer(RenderWindow& window, float player_x[], float player_y[], Sprite& playerSprite) 
{
    for (int i=0;i<3;i++)
    {
	playerSprite.setPosition(player_x[i], player_y[i]);
	window.draw(playerSprite);
	}
}

// =================================================================================================================================================================
 
void movePlayer_right (float player_x[] , float fl_x[] , float& timetrack, double& player_speed,float& bullet_x , int& present_fl,bool& right , bool& left)
{
   if ((player_x[0]<=resolutionX-64))
   {
   right=true; // to indicate the right movement ( used for bee player collision )
   left=false;
   
   player_x[0]+=player_speed*timetrack; // Moving player right by 100 units
   bullet_x+=player_speed*timetrack;    
}
}


// =================================================================================================================================================================

void movePlayer_left (float player_x[] ,float fl_x[], float& timetrack , double& player_speed, float& bullet_x, int& present_fl,bool& left , bool& right)
{
  if ((player_x[0]>=0))
  {
  left=true; // to indicate the left movement (used for player and bee collision )
  right=false;
  player_x[0]-=player_speed*timetrack; //Moving Player left by 100 units
  bullet_x-=player_speed*timetrack; 
}
}

// =================================================================================================================================================================

void moveBullet(float& bullet_y, bool& bullet_exists,bool& bullet_fired, Clock& bulletClock) {
    
	if (bulletClock.getElapsedTime().asMilliseconds() < 20)
		return;
    
	bulletClock.restart();
	bullet_y -= 10;
	if (bullet_y < -boxPixelsX)
	{
		bullet_exists = false;
		bullet_fired=false;
    }        
}

// =================================================================================================================================================================

void drawBullet(RenderWindow& window, float& bullet_x, float& bullet_y, Sprite& bulletSprite) {
	bulletSprite.setPosition(bullet_x+boxPixelsX, bullet_y);
	window.draw(bulletSprite);
	
}

// =================================================================================================================================================================

void drawBee(RenderWindow& window, float bee_x[], float bee_y[], int& present_bees ,Sprite& bee_sprite)
{
 for (int i=0; i<present_bees ; i++)
 {
 bee_sprite.setPosition(bee_x[i] , bee_y[i]);
 window.draw(bee_sprite);
 }
}

// =================================================================================================================================================================

void moveBee (float bee_x[] , float bee_y[], bool moveLeft[], bool moveRight[], int& present_bees,bool& flower_time,int& present_fl,bool& center,int& fl, float& bee_timetrack,int& bee_escape, Texture& bee_texture )
{
  flower_time=false;
  
  for (int i=0; i<present_bees ; i++)
  {
  
  if (bee_x[i]<resolutionX-boxPixelsX && bee_x[i]>0)
  {
    if (moveLeft[i]) // If bee is moving left then we subtract the coordinates 
    {
    bee_x[i]-=250*bee_timetrack;
    bee_texture.loadFromFile("Textures/Regular_bee_left.png");
    }
    else if (moveRight[i]) // If bee moves right then we add the x coordinates
    {
    bee_x[i]+=250*bee_timetrack;
    bee_texture.loadFromFile("Textures/Regular_bee_right.png");
    } 
    
  }
  else
  {
   
   if (bee_x[i]>=resolutionX-boxPixelsX) // If bee reaches the edge then reverse the direction and move one row down 
    {
     bee_y[i]+=boxPixelsY;
    moveLeft[i]=true;
    moveRight[i]=false;
    bee_x[i]=resolutionX-boxPixelsX-1;
    }
    else if (bee_x[i]<=0) // If bee reaches the edge then reverse the direction and move one row down 
    {
     bee_y[i]+=boxPixelsY;
     moveRight[i]=true;
     moveLeft[i]=false;
     bee_x[i]=1;
    }
   
   }
   center=false;
   
   // To check if the bee is one row above the spray can in order to make her exit and pollinate the flower 
   if (bee_y[i] >=(gameRows - 5) * boxPixelsY ) 
   {
            bee_escape++;
            present_fl++; // Incrementing the variable in order to draw a flower when the bee exits which is done is drawflower function
            flower_time=true;  
             if (bee_x[i] !=0 && bee_x[i]!= resolutionX-boxPixelsX)
             {
             
               center=true;
               fl=bee_x[i];
       
             }
            // To kick bee out of the frame
            bee_x[i] = -100000;  
            bee_y[i] = -100000;
            
    }
   
 } 
}
//==================================================================================================================================================================
void drawflower(RenderWindow& window, float fl_x[] , float& fl_y ,int& present_fl,bool& flower_time,bool& alt ,bool& center ,int& fl, Sprite& flower_sprite)
{
for (int i=0; i<present_fl; i++)
{
    
   // if the first bee is exiting the frame then we draw flowers on the both edges of the screen
           if (present_fl==1)
           {
            fl_x[i]=0; // draw on left edge
             flower_sprite.setPosition(fl_x[i], fl_y);
             window.draw(flower_sprite);
            fl_x[i+1]=resolutionX-boxPixelsX; // draw on the right edge
              flower_sprite.setPosition(fl_x[i+1], fl_y);
            window.draw(flower_sprite);
           } 
           else 
           {
           // The Flowers Pollinated by the first bee ( on the edges of the player ground ) 
           fl_x[0]=0;
             flower_sprite.setPosition(fl_x[i], fl_y);
             window.draw(flower_sprite);
             
            fl_x[1]=resolutionX-boxPixelsX;
              flower_sprite.setPosition(fl_x[i+1], fl_y);
            window.draw(flower_sprite);
           
          // and when the second third and further bee's exit, one flower is draw alternatingly on left and right sides of the screen
           if (i%2==0)
           {
            fl_x[i+2]=boxPixelsX*(i);
            flower_sprite.setPosition(fl_x[i+2], fl_y);
            window.draw(flower_sprite);
           }
           else if (i%2!=0)
           {
            fl_x[i+2]=(resolutionX-boxPixelsX)-(boxPixelsX*(i));
            flower_sprite.setPosition(fl_x[i+2], fl_y);
            window.draw(flower_sprite);
           
           }           
   }
  
        
 }  
     
     
}
// =================================================================================================================================================================

void bee_spawn(float bee_x[], float bee_y[], int& present_bees,const int& max_bees ,Clock& beespawn)
{
 // To give an interval in bee spawining
  if (beespawn.getElapsedTime().asSeconds() < (rand()%50+1))
  return;
 
 else
 {
   if (present_bees < max_bees)
   {
   bee_x[present_bees]=0; bee_y[present_bees]=rand()%(gameRows - 6) * boxPixelsY;;
   present_bees++;
   beespawn.restart();
   }
 }
}

// =================================================================================================================================================================

void bullet_bee_collision (float& bullet_x, float& bullet_y, float bee_x[], float bee_y[],int honeycomb_x[] ,int honeycomb_y[], int& present_bees, int& honeycomb, bool&collision_status, bool& bullet_exists ,int& Score,int& reg_bee_killed,int& max_honeycomb, Music& collision) {
    int bullet_width=boxPixelsX;  // Bullet width for collision detection
    int bullet_height=boxPixelsX; // Bullet height for collision detection
    int bee_width=boxPixelsX;     // Bee width for collision detection
    int bee_height=boxPixelsX;    // Bee height for collision detection
   bool bee_knocked;
    
    for (int i=0; i<present_bees; i++) {
       bool horizontal_collision=( bullet_x + bullet_width>=bee_x[i] )&&( bullet_x<=bee_x[i] + bee_width);
         /* 
         The Horizontal coliison checks if the right edge of the bullet is right to the left edge of the bee and the
            left edge of the bullet is left to the right edge of bee    
         */ 
         bool vertical_collision=( bullet_y + bullet_height>=bee_y[i]) && (bullet_y<=bee_y[i] + bee_height);
         /* 
         The Vertical collision checks if the bottom edge of the bullet is below the top edge of the bee and the
          top edge of the bullet is above the bottom edge of the bee
         */
         bee_knocked=false;
         
        if (horizontal_collision && vertical_collision) {
              
            if (!bee_knocked)
            {
            collision.play();
            Score+=100; 
            reg_bee_killed++;
            collision_status==true;
            bullet_exists=false; // To make sure bullet terminates after eliminating a bee
            bee_knocked=true;
            
            // When a bee is eliminated, a honeycomb is drawn at that place so assigning the respective honeycomb the coordinates of eliminated bee
            if (honeycomb<max_honeycomb)
            { 
            honeycomb_x[honeycomb]=bee_x[i]; 
            honeycomb_y[honeycomb]=bee_y[i];
            honeycomb++;
            }
            // Throwing the bee out of the frame
            
                bee_x[i]=-10000000000;
                bee_y[i]=-10000000000;
                
        }
        break;
    }
    else {
        collision_status=false;
    }
    
  }
 }
 // =================================================================================================================================================================
 
void bee_comb_collision ( float bee_x[] , float bee_y[] , int honeycomb_x[], int honeycomb_y[], float hives_x[] , float hives_y[], int& present_bees,int& honeycomb,int& hives , float& timetrack )
{
    int comb_width=boxPixelsX;  // Honeycomb width for collision detection
    int comb_height=boxPixelsX; // Honeycomb height for collision detection
    int bee_width=boxPixelsX;     // Bee width for collision detection
    int bee_height=boxPixelsX;  //Bee height for collision detection
    
    for (int i=0; i<present_bees; i++) {
    
       for (int j=0;j<honeycomb;j++)
       {
    
         bool horizontal_collision=( honeycomb_x[j] + comb_width>=bee_x[i] )&&( honeycomb_x[j]<=bee_x[i] + bee_width);
         /* The Horizontal coliison checks if the right edge of the honeycomb is right to the left edge of the bee and the
            left edge of the honeycomb is left to the right edge of bee    
         */ 
         bool vertical_collision=( honeycomb_y[j] + comb_height>=bee_y[i]) && (honeycomb_y[j]<=bee_y[i] + bee_height);
         /* The Vertical collision checks if the bottom edge of the honey comb is below the top edge of the bee and the
          top edge of the comb is above the bottom edge of the bee
         */
    
        if ( horizontal_collision && vertical_collision)
        {
         bee_x[i]-=250*timetrack; // Stopping the bee by cancelling the further movement
         bee_y[i]+=boxPixelsY*timetrack; // Moving the bee on row down
         
         bool honeycomb_beneath=false; // To check whether there is a honeycomb under the honeycomb which is cruicial for hive generation
         
         for (int k=0; k<honeycomb;k++)
         {
          if ((honeycomb_y[k]!=honeycomb_y[j])&& (honeycomb_x[k]!=honeycomb_x[i])) // Making sure the bee's collision is not checked with the same honeycomb
          {
          if (((bee_y[i]+bee_height>=honeycomb_y[k])&& (bee_y[i]<=honeycomb_y[k]+comb_height))&& (bee_x[i]+bee_width >= honeycomb_x[k])&& (bee_x[i]<= honeycomb_x[k]+comb_width))
           {
             honeycomb_beneath=true;
             break; 
           }
          }
          } 
            if  (hives<=present_bees)
            {
             if (honeycomb_beneath) // If a honeycomb exits beneath the bee then hive is formed at that point and bee exits the frame
            {
            hives_x[hives]=bee_x[i];
            hives_y[hives]=bee_y[i];
            
            bee_x[i]=-100000;
            bee_y[i]=-100000;
            
            hives++;
            }
           }
         }
        }
        


  }

}

  
// =================================================================================================================================================================

void drawHoneycomb (RenderWindow& window, int honeycomb_x[], int honeycomb_y[],int& tempX , int& tempY, int& honeycomb ,bool& collision_status ,int& max_honeycomb, Sprite& comb_sprite)
{

for (int i=0; i<honeycomb ; i++)
{
 comb_sprite.setPosition(honeycomb_x[i] , honeycomb_y[i]);
 window.draw(comb_sprite);
}

}

//=====================================================================================================================================================================
void bullet_comb_collision ( float& bullet_x , float& bullet_y , int honeycomb_x [], int honeycomb_y [], int& honeycomb,bool& bullet_exists,int& max_honeycomb, Music& collision)
{
 

    int comb_width=boxPixelsX;  
    int comb_height=boxPixelsX; 
    int bullet_width=boxPixelsX;     
    int bullet_height=boxPixelsX;
    if (honeycomb < max_honeycomb)
    {
     for (int i=0; i<=honeycomb; i++) 
     {
       bool horizontal_collision=( bullet_x + bullet_width>=honeycomb_x[i] )&&( bullet_x<=honeycomb_x[i] + comb_width);
         /* The Horizontal coliison checks if the right edge of the bullet is right to the left edge of the honeycomb and the
            left edge of the bullet is left to the right edge of honeycomb    
         */ 
         bool vertical_collision=( bullet_y + bullet_height>=honeycomb_y[i]) && (bullet_y<=honeycomb_y[i] + comb_height);
         /* The Vertical collision checks if the bottom edge of the bullet is below the top edge of the honeycomb and the
          top edge of the bullet is above the bottom edge of the honeycomb
         */  
         
         if (horizontal_collision && vertical_collision)
         {
          honeycomb_x[i]=-100000;
          honeycomb_y[i]=-100000;
          collision.play();
          bullet_exists=false;
         }
            
    }
    
}
}
//============================================================================================================================================================
/*
void bee_stop ( float bee_x[] , float bee_y[], bool moveRight[] , bool moveLeft[], int& present_bees,float& timetrack)
{
 int pause;
 pause=rand()%5;
 
 for (int i=0; i<present_bees; i++)
 {
 if ( pause==0)
 {
  if (moveRight[i])
  {
   bee_x[i]-=250*timetrack;
  }
  else if (moveLeft[i])
  {
   bee_x[i]+=250*timetrack;
  }
 
 }

 }
} */

//=========================================================================================================================================================================

void player_fl ( float player_x[] , float fl_x[], float& bullet_x , int& present_fl , double& player_speed , float& timetrack, bool& left , bool& right )
{
 
    int player_width=boxPixelsX;  
    int player_height=boxPixelsX; 
    int fl_width=boxPixelsX;     
    int fl_height=boxPixelsX;
    
     if (present_fl<gameColumns)
     {
     for (int i=0 ; i<present_fl; i++)
     {
      
     
       bool horizontal_collision=(( player_x[0]<=fl_x[i] + fl_width) && (fl_x[i]<=player_x[0]+player_width));
       
       // To check whether the player is colliding with the flowers on both sides or not
       
    
         if (horizontal_collision)
         {
          if (left) // If player is colliding and from left then restrict its movement by pushing it out
          {
          if ((player_x[0]<=resolutionX-64))
          {
          player_x[0]+=player_speed*timetrack;
          bullet_x+=player_speed*timetrack;
          
          
          }
          }
          else if (right) // If player is colliding and from right then restrict its movement by pushing it out
          {
          if (player_x[0]>=0)
          {
          player_x[0]-=player_speed*timetrack;
          bullet_x-=player_speed*timetrack;
          
          }
          }
         }
              
}
}
}
//=========================================================================================================================================================================

void humming_bird (RenderWindow& window, float& h_bird_x , float& h_bird_y, float& timetrack, bool& alt , int& destination_x , int& destination_y, Sprite& humming_sprite, Clock& h_bird)

{
 
 
 // The destination variable values are generated randomly at the point of initialization and re freshed each time bird reaches its destination
 
 if (h_bird_x<destination_x) // if the bird is behind its destination then we increase its x coordinates so it gets near its destination
 {
    h_bird_x+=(boxPixelsX)*timetrack;
    
    
   if (h_bird_x>destination_x) // if the bird gets ahead of its destination then we bring it back 
   {
    h_bird_x=destination_x;
   } 
 
   if (h_bird.getElapsedTime().asSeconds()>5) // To give a brief pause after reaching its destination
    {
  
     h_bird.restart();
    }  
 }   
  
 
 else if (h_bird_x>destination_x) // if the bird is ahead its destination then we decrease its x coordinates so it gets near its destination
 {
    h_bird_x-=(boxPixelsX)*timetrack;
    
   if (h_bird_x<destination_x) // if the bird gets behind of its destination then we bring it back
   {
    h_bird_x=destination_x;
   } 
   
   if (h_bird.getElapsedTime().asSeconds()>5)
    {
  
     h_bird.restart();
    }  
 
 }  
 
 
 if (h_bird_y<destination_y)
 {
    h_bird_y+=(boxPixelsY)*timetrack;
    
   if (h_bird_y>destination_y)
   {
    h_bird_y=destination_y;
   } 
   if (h_bird.getElapsedTime().asSeconds()>5)
    {
  
     h_bird.restart();
    }  
 
 }  
 
 else if (h_bird_y>destination_y)
 {
    h_bird_y-=(boxPixelsY)*timetrack;
    
   if (h_bird_y<destination_y)
   {
    h_bird_y=destination_y;
   }
   if (h_bird.getElapsedTime().asSeconds()>5)
    {
  
     h_bird.restart();
    }   
 
 }  
 
 // if the bird reaches its destination then we assign her new destination coordinates
 
 if ((h_bird_x==destination_x) && (h_bird_y==destination_y))
 {
 
  if (h_bird.getElapsedTime().asSeconds()>5)
  {
  
  destination_x=rand()%(resolutionX-boxPixelsX)+1;
  destination_y=rand()%(gameRows - 4) * boxPixelsY;
 
  h_bird.restart();
    
 
 } 
}
  humming_sprite.setPosition( h_bird_x , h_bird_y );
  window.draw(humming_sprite);

}
//===============================================================================================================================================================
void drawHives ( RenderWindow& window , float hives_x[] , float hives_y[],int& hives,int& max_hives,Sprite& hive_sprite )
{
 if (hives<max_hives)
 {
 for (int i=0; i<hives ; i++)
 {
  hive_sprite.setPosition( hives_x[i] , hives_y[i] );
  window.draw(hive_sprite);    
 }
 }
}

//==================================================================================================================================================================
void bullet_hive_collision ( float hives_x [] , float hives_y [] , float& bullet_x, float& bullet_y, int& hives, bool& bullet_exists)
{
    int bullet_width=boxPixelsX;  
    int bullet_height=boxPixelsX; 
    int hive_width=boxPixelsX;     
    int hive_height=boxPixelsX;
    
   for (int i=0 ;i<hives ; i++) 
    {

      bool horizontal_collision=( bullet_x + bullet_width>=hives_x[i] )&&( bullet_x<=hives_x[i] + hive_width);
  
      bool vertical_collision=( bullet_y + bullet_height>=hives_y[i]) && (bullet_y <= hives_y[i] + hive_height);
 
  if ( horizontal_collision && vertical_collision )
     {
   hives_x[i]=-100000;
   hives_y[i]= -100000;        
   bullet_exists=false;
     }
}
}
//========================================================================================================================================================================
void draw_fast_bees ( RenderWindow& window, float fast_bee_x [] , float fast_bee_y [] ,int& present_fast , int& max_fast,Sprite& fast_sprite )
{
if (present_fast <= max_fast )
{
for (int i=0; i<present_fast ; i++)
 {
 fast_sprite.setPosition(fast_bee_x[i] ,fast_bee_y[i]);
 window.draw(fast_sprite);
 }
}
}

//============================================================================================================================================================================
void spawn_fast_bees ( float fast_bee_x [] , float fast_bee_y [] , int& present_fast, int&  max_fast ,Clock& fast_bee_clock)
{
 
  if (fast_bee_clock.getElapsedTime().asSeconds() < (rand()%60+1))
  return;
 
 else
 {
   if (present_fast < max_fast)
   {
   fast_bee_x[present_fast]=0; fast_bee_y[present_fast]=rand()%(gameRows - 7) * boxPixelsY;;
   present_fast++;
   fast_bee_clock.restart();
   }
 }
}

//==============================================================================================================================================================================
void move_fast_bees ( float fast_bee_x [] , float fast_bee_y [] , int& present_fast , int& max_fast , bool left_fast[] , bool right_fast[],int& present_fl,float& timetrack )
{
 if (present_fast <= max_fast )
 {
  
  for (int i=0; i<present_fast ; i++)
  {
  
  if (fast_bee_x[i]<resolutionX-boxPixelsX && fast_bee_x[i]>0)
  {
    if (left_fast[i])
    {
    fast_bee_x[i]-=450*timetrack;
    }
    else if (right_fast[i])
    {
    fast_bee_x[i]+=450*timetrack;
    } 
    
  }
  else
  {
   
   if (fast_bee_x[i]>=resolutionX-boxPixelsX)
    {
    
    fast_bee_y[i]+=boxPixelsY;
    left_fast[i]=true;
    right_fast[i]=false;
    fast_bee_x[i]=resolutionX-boxPixelsX-1;
    
    }
    else if (fast_bee_x[i]<=0)
    {
    
     fast_bee_y[i]+=boxPixelsY;
     right_fast[i]=true;
     left_fast[i]=false;
     fast_bee_x[i]=1;
    
    }
   
   }
   
   if (fast_bee_y[i] >=(gameRows - 5) * boxPixelsY ) 
   {
            present_fl++;
          /*  
             if (fast_bee_x[i] !=0 && fast_bee_x[i]!= resolutionX-boxPixelsX)
             {
               center=true;
               fl=fastbee_x[i];
       
             }
           */  
            fast_bee_x[i] = -100000;  
            fast_bee_y[i] = -100000;
            
    }
   
   }
  } 
}

//=============================================================================================================================================================================
void bullet_fast_bee_collision ( float& bullet_x , float& bullet_y ,float fast_bee_x [] , float fast_bee_y [] , float red_x [] , float red_y [] , int& present_fast ,int& present_red_comb, bool& bullet_exists ,int& Score ,int& fast_bee_killed , Music& collision )
{
     int bullet_width=boxPixelsX;  // Bullet width for collision detection
     int bullet_height=boxPixelsX; // Bullet height for collision detection
     int fast_bee_width=boxPixelsX;  // Bee width for collision detection
     int fast_bee_height=boxPixelsX; // Bee height for collision detection
     bool bee_knocked;
    
    for (int i=0; i<present_fast; i++) 
    {
       bool horizontal_collision=( bullet_x + bullet_width>=fast_bee_x[i] )&&( bullet_x<=fast_bee_x[i] + fast_bee_width);
          
       bool vertical_collision=( bullet_y + bullet_height>=fast_bee_y[i]) && (bullet_y<=fast_bee_y[i] + fast_bee_height);
         
         bee_knocked=false;
         
        if (horizontal_collision && vertical_collision) {
              
            if (!bee_knocked)
            {
            collision.play();
            Score+=1000;
            fast_bee_killed++;
           // collision_status==true;
            bullet_exists=false;
            bee_knocked=true;
            
            if (present_red_comb<present_fast)
            { 
            red_x[present_red_comb]=fast_bee_x[i];
            red_y[present_red_comb]=fast_bee_y[i];
            present_red_comb++;
            }
            
                fast_bee_x[i]=-100000000;
                fast_bee_y[i]=-100000000;
                
        }
        break;
    }
    
    
  }
 }



//=================================================================================================================================================================
void draw_red_comb (RenderWindow& window, float red_x [], float red_y [], int& present_red_comb , Sprite& red_sprite)
{
for (int i=0; i<present_red_comb ; i++)
{
 red_sprite.setPosition(red_x[i] , red_y[i]);
 window.draw(red_sprite);
}

}

//=====================================================================================================================================================================
void reg_bee_red_comb ( float bee_x [] ,float bee_y [], float red_x [] , float red_y [] , int& present_bees , int& present_red_comb, float& timetrack,int& hives ,float hives_x[], float hives_y[])
{
     int red_comb_width=boxPixelsX;  //RED Honeycomb width for collision detection
     int red_comb_height=boxPixelsX; //RED Honeycomb height for collision detection
     int bee_width=boxPixelsX;     //  REGULAR Bee width for collision detection
     int bee_height=boxPixelsX;  // REGULAR Bee height for collision detection
    
    for (int i=0; i<present_bees; i++) {
    
       for (int j=0;j<present_red_comb;j++)
       {
    
         bool horizontal_collision=( red_x[j] + red_comb_width>=bee_x[i] )&&( red_x[j]<=bee_x[i] + bee_width);
            
         bool vertical_collision=( red_y[j] + red_comb_height>=bee_y[i]) && (red_y[j]<=bee_y[i] + bee_height);
        
    
        if ( horizontal_collision && vertical_collision)
        {
         bee_x[i]-=250*timetrack;
         bee_y[i]+=boxPixelsY*timetrack;
         
         bool honeycomb_beneath=false;
         
         for (int k=0; k<present_red_comb;k++)
         {
          if ((red_y[k]!=red_y[j])&& (red_x[k]!=red_x[i]))
          {
          if (((bee_y[i]+bee_height>=red_y[k])&& (bee_y[i]<=red_y[k]+red_comb_height))&& (bee_x[i]+bee_width >= red_x[k])&& (bee_x[i]<= red_x[k]+ red_comb_width))
           {
             honeycomb_beneath=true;
             break; 
           }
          }
          } 
            if  (hives<=present_bees)
            {
             if (honeycomb_beneath)
            {
            hives_x[hives]=bee_x[i];
            hives_y[hives]=bee_y[i];
            
            bee_x[i]=-100000;
            bee_y[i]=-100000;
            
            hives++;
            }
           }
         }
        }
        


  }

}
//==========================================================================================================================================================
 void bullet_red_comb ( float red_x[] , float red_y [] , float& bullet_x , float& bullet_y , int& present_red_comb )
{
     int red_comb_width=boxPixelsX;  
     int red_comb_height=boxPixelsX; 
     int bullet_width=boxPixelsX;     
     int bullet_height=boxPixelsX;  
     
     for (int i=0; i<present_red_comb ;i++)
     {
     
         bool horizontal_collision=( red_x[i] + red_comb_width>=bullet_x )&&( red_x[i]<=bullet_x + bullet_width);
            
         bool vertical_collision=( red_y[i] + red_comb_height>=bullet_y) && (red_y[i]<=bullet_y + bullet_height); 
         
         if (horizontal_collision && vertical_collision)
         {
         red_x[i]=-100000;
         red_y[i]=-100000;
         }
        
}
}
//=============================================================================================================================================================
void h_bird_comb_collision (float& h_bird_x ,float& h_bird_y , int honeycomb_x[], int honeycomb_y[] , float red_x[] , float red_y[] , int& present_red_comb , int& honeycomb, int& Score )
{
     int h_bird_height=32;
     int h_bird_width=32;
     int comb_height=32;
     int comb_width=32;
     int red_comb_height=32;
     int red_comb_width=32;
     
     for (int i=0; i<honeycomb ; i++)
     {
     bool horizontal_collision_comb= ( h_bird_x + h_bird_width>=honeycomb_x[i])&&(h_bird_x<= honeycomb_x[i]+comb_width);
            
     bool vertical_collision_comb= (h_bird_y + h_bird_height >= honeycomb_y[i])&&(h_bird_y<= honeycomb_y[i]+comb_height);
     
     if (horizontal_collision_comb && vertical_collision_comb)
     {
     
      if (honeycomb_y[i]==0 || honeycomb_y[i]==boxPixelsY) // Top two tiers
     { Score+=1000; }
      
      else if (honeycomb_y[i]== boxPixelsY*2 || honeycomb_y[i]==boxPixelsY*3 || honeycomb_y[i]==boxPixelsY*4) // 3 ,4 ,5 tier
     { Score+=800; }
     
     else // the remaining tiers
     { Score+=500; }
     
      honeycomb_x[i]=-1000 ;
      honeycomb_y[i]=-1000;    
     }
     
    }
    
    for (int i=0; i<present_red_comb; i++)
    {
    
    bool horizontal_collision_red= ( h_bird_x+h_bird_width >= red_x[i])&&(h_bird_x <= red_x[i]+red_comb_width);
    
    bool vertical_collision_red= (h_bird_y+h_bird_height>= red_y[i]) && (h_bird_y <= red_y[i]+red_comb_height);
    
    if (horizontal_collision_red && vertical_collision_red)
    {
    
     
      if (red_y[i]==0 || red_y[i]==boxPixelsY) // Top two tiers
     { Score+=2000; }
      
      else if (red_y[i]== boxPixelsY*2 || red_y[i]==boxPixelsY*3 || red_y[i]==boxPixelsY*4) // 3,4,5 tier
     { Score+=1800; }
     
     else // the remaining ones
     { Score+=1500; }
    
   
    red_x[i]=-1000 ;
    red_y[i]=-1000 ;
    }
    
    
    
    }

}
//==========================================================================================================================================================================
void bullet_h_bird_collision ( float& bullet_x , float& bullet_y, float& h_bird_x, float& h_bird_y ,int& h_bird_hit,float& timetrack,bool& bullet_exists, Clock& h_bird )
{
  int bullet_width=boxPixelsX;
  int bullet_height=boxPixelsX;
  int h_bird_width=boxPixelsX;
  int h_bird_height=boxPixelsX;
  

  
  bool horizontal_collision= (bullet_x + bullet_width >=h_bird_x)&&(bullet_x<= h_bird_x + h_bird_width); 
  
  bool vertical_collision= (bullet_y + bullet_height >=h_bird_y)&&(bullet_y<= h_bird_y + h_bird_height); 

 if (horizontal_collision && vertical_collision )
 {
  h_bird_hit++;
  bullet_exists=false;
 }
 
  if (h_bird_hit >=3)
  {
    h_bird_x+=200*timetrack;
    
    if (h_bird_x>=resolutionX-boxPixelsX)
    {
     h_bird_x=1000;
     h_bird_y=1000;
     h_bird_hit=0;
    }
   if (h_bird.getElapsedTime().asSeconds() >=6)
  {
   h_bird_x=resolutionX-boxPixelsX-1;
   h_bird_y= (gameColumns-5)*boxPixelsX;
  }
  }
  
}

//============================================================================================================================================================================
